import java.sql.Timestamp
import java.util

import org.apache.spark.sql.functions._
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.sql.types.DateType
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.apache.spark.streaming.Duration
import org.apache.spark.streaming.Durations
import org.apache.spark.streaming.api.java.JavaDStream
import org.apache.spark.streaming.api.java.JavaInputDStream
import org.apache.spark.streaming.api.java.JavaStreamingContext
import org.apache.spark.streaming.kafka010.ConsumerStrategies
import org.apache.spark.streaming.kafka010.KafkaUtils
import org.apache.spark.streaming.kafka010.LocationStrategies
case class MyData(Id: Int, CreationDate:Timestamp,OwnerUserId:Int,Tags:String)

object SparkStructuredStream {
  def main(args: Array[String]): Unit = {

    import com.sun.rowset.internal.Row
  //  System.setProperty("hadoop.home.dir", "c:/hadoop")
    Logger.getLogger("org.apache").setLevel(Level.WARN)
    Logger.getLogger("org.apache.spark.storage").setLevel(Level.ERROR)


    val session = SparkSession.builder.master("local[*]").appName("structuredViewingReport").getOrCreate
    import org.apache.spark.sql.{Encoder, Encoders}
    import session.implicits._

    import org.apache.spark.sql.types.DataTypes
    import org.apache.spark.sql.types.StructField
    import org.apache.spark.sql.types.StructType


    val schema = DataTypes.
      createStructType(Array[StructField](DataTypes.createStructField("Id",
        DataTypes.IntegerType, false), DataTypes.createStructField("CreationDate",
        DataTypes.TimestampType, false), DataTypes.createStructField("OwnerUserId",
        DataTypes.IntegerType, false),DataTypes.createStructField("Tags", DataTypes.StringType, true)))

    import org.apache.spark.sql.Encoders
  //  val carEncoder = Encoders.product[MyData]

    import org.apache.spark.sql.functions
   val df = session.readStream.format("kafka")
     .option("kafka.bootstrap.servers","localhost:9092")
     .option("multiLine",true)
     .option("subscribe", "stream").load()
     .selectExpr("CAST(value AS STRING) ")
     .select(functions.from_json($"value",schema).as("json")).
     select("json.*").as[MyData]

   val newDF = df.withColumn("CreationDate", df("CreationDate").cast(DateType))
   val df1= newDF.withColumn("Tags",translate('Tags, "<", ""))
   val df2= df1.withColumn("Tags",  translate('Tags, ">", ","))
    //val l=length($"Tags").as[Int]
   // val df3= df2.withColumn("Tags", substring('Tags, 0,length($"Tags").as[Int]))

    val df3= df2.withColumn("Tags", split('Tags, ","))

    val df4= df3.withColumn("Tags", explode('Tags))
    val df5=df4.filter(df4("Tags") =!= "")

  // df5.selectExpr("select count(*),month(CreationDate)")
   //val df5= df4.where(df4.col("Tags").isNotNull)
   //val df5= df4.filter(column("Tags").isNotNull)
   //val df5= df4.where(df4.col("Tags").isNotNull)



  //print(results.getClass)
  // val re= session.readStream.format("kafka").option("kafka.bootstrap.servers", "localhost:9092").option("subscribe", "stream").load
   // val r=results.select("Id").where("Id > 2")
   // val words = results.as[MyData]

   // println(words)


   // val words=results.map(x=>x.mkString)
  //  println(results)
   df5.createOrReplaceTempView("people")

    val sqlDF = session.sql("SELECT Tags,Count(Id),Month(CreationDate) FROM people group by Tags,month(CreationDate)")


    import org.apache.spark.sql.streaming.OutputMode
    import org.apache.spark.sql.streaming.StreamingQuery

    //val newr=session.sql("ALTER TABLE tableview alter CreationDate date")
  // val results1 = session.sql("select cast(value as string) from people");
    val query = sqlDF.writeStream.format("console").outputMode(OutputMode.Update()).option("truncate", false).option("numRows", 100).start

    query.awaitTermination()


  }
}
