import java.sql.Timestamp

import org.apache.spark.SparkConf
import org.apache.spark.streaming.{Duration, Durations, StreamingContext}
import java.util

import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.streaming.Durations
import org.apache.spark.streaming.api.java.JavaDStream
import org.apache.spark.streaming.api.java.JavaInputDStream
import org.apache.spark.streaming.api.java.JavaStreamingContext
import org.apache.spark.streaming.dstream.InputDStream
import org.apache.spark.streaming.kafka010.ConsumerStrategies
import org.apache.spark.streaming.kafka010.KafkaUtils
import org.apache.spark.streaming.kafka010.LocationStrategies


object SparkDStream {

  def main(args: Array[String]): Unit = {

    Logger.getLogger("org.apache").setLevel(Level.WARN)
    Logger.getLogger("org.apache.spark.storage").setLevel(Level.ERROR)
    val conf: SparkConf = new SparkConf().setMaster("local[*]").setAppName("nifi")

    val sc = new StreamingContext(conf, Durations.seconds(1))

    val topics: util.Collection[String] = util.Arrays.asList("test")

    val params = new util.HashMap[String, AnyRef]
    params.put("bootstrap.servers", "localhost:9092")
    params.put("key.deserializer", classOf[StringDeserializer])
    params.put("value.deserializer", classOf[StringDeserializer])
    params.put("group.id", "consumerGroup1")
    params.put("auto.offset.reset", "latest")

   val stream:InputDStream[ConsumerRecord[String,String]]= KafkaUtils.createDirectStream(sc, LocationStrategies.PreferConsistent,
     ConsumerStrategies.Subscribe(topics, params))
   val c= stream.map(x=>x.value()).getClass
    print(c)
   val newm= stream.map(x=>x.value().mkString.split("\n").mkString).print()
  // val newm= stream.map(x=>(x.value().,1)).print()
   // val newm1=newm.m

    sc.start()
    sc.awaitTermination()
  }
}