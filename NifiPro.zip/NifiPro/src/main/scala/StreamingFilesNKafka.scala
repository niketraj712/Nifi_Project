

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.types.{IntegerType, StringType, StructType, TimestampType}
import org.apache.spark.sql.functions._

object StreamingFilesNKafka {
  def main(args: Array[String]): Unit = {
    Logger.getLogger("org.apache").setLevel(Level.WARN)
    Logger.getLogger("org.apache.spark.storage").setLevel(Level.ERROR)
  val spark = SparkSession.builder().
    appName("streaming files").
    master("local[*]").
    getOrCreate()

  import spark.implicits._

  val schema = new StructType().
    add("Id", IntegerType).
    add("CreationDate",TimestampType).
    add("OwnerUserId", IntegerType).
    add("Tags",StringType)

   /*def readFromFiles() = {

    val lines = spark.readStream.
      schema(schema).
      format("json").
      load("C:\\Users\\kenche's\\Downloads\\data")

    lines.writeStream.
      format("console").
      outputMode("append").
      start().
      awaitTermination()

  }*/




    val kafkaDF: DataFrame = spark.readStream.
      format("kafka").
      option("kafka.bootstrap.servers", "localhost:9092").
      option("subscribe", "stream").
      option("multiline",true).
      load().
      select(expr("cast(value as string) as actualValue")).
      select(from_json(col("actualValue"), schema).as("tags")).
      selectExpr("tags.Id as id", "tags.CreationDate as creationDate", "tags.OwnerUserId as ownerUserId", "tags.Tags as tag")



    val kafkaDF2 = kafkaDF.withColumn("tag", translate('tag, "<", "")).
      withColumn("tag", translate('tag, ">", ",")).
      withColumn("tag", split('tag, ",")).
      withColumn("tag", explode('tag)).
      filter('tag =!= "").
      select('id, 'creationDate, 'ownerUserId, 'tag)


    kafkaDF2.
      writeStream.
      format("console").
      outputMode("append").
      start().
      awaitTermination()






  }

}
