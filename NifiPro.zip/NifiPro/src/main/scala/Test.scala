
import java.time.Duration

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession

import collection.JavaConverters._

object Test {
  def main(args: Array[String]): Unit = {
    Logger.getLogger("org.apache").setLevel(Level.WARN)
    Logger.getLogger("org.apache.spark.storage").setLevel(Level.ERROR)
    val spark = SparkSession.builder().
      appName("streaming files").
      master("local[*]").
      getOrCreate()

    val df=spark.read.option("multiLine", true).json("C:\\Users\\niketraj\\Desktop\\target\\trget.json")

    df.show()

  }}
